﻿namespace ChoparPizza.Domain.Enums
{
    public enum ItemState
    {
        Created = 1,
        Updated,
        Deleted
    }
}
