﻿using ChoparPizza.Domain.Entities.Users;

namespace ChoparPizza.Data.IRepositories
{
    public interface IUserRepository : IGenericRepository<User>
    {
    }
}
