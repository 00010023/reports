﻿namespace LibraryManagement
{
    public enum AccountRole
    {
        Student,
        Librarian,
        Admin
    }
}