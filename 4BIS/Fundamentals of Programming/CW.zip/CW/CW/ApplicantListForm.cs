﻿using System;
using CW.DAL;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CW
{
    public partial class ApplicantListForm : Form
    {
        // Initializes the design part of the program
        public ApplicantListForm()
        {
            InitializeComponent();
        }

        // Initializes the datas by getting them from
        // backend
        private void ApplicantListForm_Load(object sender, EventArgs e)
        {
            MdiParent = MyForms.GetForm<ParentForm>();
            LoadData();
        }

        // The refresh button that does the same as the
        // formload function
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        // The function that stands for refreshability of
        // the datas coming up from the backend
        public void LoadData()
        {
            dgv.DataMember = "";
            dgv.DataSource = null;
            dgv.DataSource = new ApplicantList().GetAllApplicants();
        }

        // The sort button that helps to get informations sorted
        // out by its name, category or tests taken
        private void btnSort_Click(object sender, EventArgs e)
        {
            if (cbxSort.SelectedIndex < 0)
                MessageBox.Show("Select an attribute to sort by");
            else
            {
                ByAttribute selectedAttribute;
                if (cbxSort.SelectedIndex == 0)
                    selectedAttribute = ByAttribute.ap_name_10023;
                else if (cbxSort.SelectedIndex == 1)
                    selectedAttribute = ByAttribute.ap_score_10023;
                else selectedAttribute = ByAttribute.ap_tests_taken_10023;

                dgv.DataMember = "";
                dgv.DataSource = null;
                dgv.DataSource = new ApplicantList().Sort(selectedAttribute);
            }

        }

        // The search button that takes all string from the cbxSearch combobox
        // and uses the backend function to search given result that will end
        // up showing sorted datas that will be retrieved from backend
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (cbxSearch.SelectedIndex < 0)
                MessageBox.Show("Select an attribute to search by");
            else if (string.IsNullOrWhiteSpace(tbxSearch.Text))
                MessageBox.Show("Provide the search term");
            else
            {
                var selectedAttribute = cbxSearch.SelectedIndex == 0 ? ByAttribute.ap_name_10023 : ByAttribute.ap_tests_taken_10023;

                dgv.DataMember = "";
                dgv.DataSource = null;
                dgv.DataSource = new ApplicantList().Search(tbxSearch.Text, selectedAttribute);
            }

        }

        // The delete button that is responsibe for deleting
        // datas from the database side by connecting with its
        // CW.DAL
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0)
                MessageBox.Show("Please select an applicant");
            else
            {
                var a = (Applicant)dgv.SelectedRows[0].DataBoundItem;
                new ApplicantManager().Delete(a.ap_id_10023);
                LoadData();
            }
        }

        // The update button that does help user to manage or edit
        // existing data that is located at the database
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0)
                MessageBox.Show("Please select a course");
            else
            {
                var a = (Applicant)dgv.SelectedRows[0].DataBoundItem;
                new ApplicantEditForm().UpdateApplicant(a);
            }
        }

        // The create button that does create an Applicant by
        // telling it to its backend side namely CW.DAL
        private void btnAdd_Click(object sender, EventArgs e)
        {
            new ApplicantEditForm().CreateNewApplicant();
        }
    }
}
