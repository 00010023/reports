﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW
{
    // The class where do I save all method of
    // <Bla bla>EditFor.cs
    public enum FormMode
    {
        CreateNew,
        Update
    }
}
