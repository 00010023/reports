﻿using CW.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CW
{
    public partial class ParentForm : Form
    {
        // Initializing the main part of the programs
        public ParentForm()
        {
            InitializeComponent();
        }

        // The exit button that is located inside menuStrip
        // that will close the whole program
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // The about button in menuStrip that creates the
        // AboutForm window 
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var about = new AboutForm(); about.ShowDialog();
        }

        // A method that was used to test and play with some
        // backend things but not used anymore. Saaaad...
        private void ParentForm_Load(object sender, EventArgs e)
        {
            /*
            var testList = new TestList();
            var tests = testList.GetAllTests();

            MessageBox.Show(tests.Count.ToString());
            */
        }

        // The All Applicants menuStrip button that spawns an Applicant
        // creating window which will help you to create an Applicant
        private void allApplicantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyForms.GetForm<ApplicantListForm>().Show();
        }

        // The alltests button that will spawn TestListForm
        private void allTestsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyForms.GetForm<TestListForm>().Show();
        }

        // The NewTest button that will spawn TestEditForm with
        // empty credentials
        private void newTestsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new TestEditForm().CreateNewTest();
        }

        // The new applicant form windows that will spawn
        // ApplicantEditForm window withits new credentials
        private void newApplicantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new ApplicantEditForm().CreateNewApplicant();
        }
    }
}
