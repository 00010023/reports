﻿using CW.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CW
{
    public partial class TestEditForm : Form
    {
        // Initializing the component design
        public TestEditForm()
        {
            InitializeComponent();
        }

        // Initializing the setter and getters of
        // Test class in CW.DAL
        public Test Test { get; set; }

        // The same thing is goin' on here also
        // in the FormMode setters and getters
        public FormMode Mode { get; set; }

        // The mechanic of class "create" function
        // and its his beauty described via usage
        // of MdiParen respectives
        public void CreateNewTest()
        {
            Mode = FormMode.CreateNew;
            Test = new Test();
            InitializeControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        // Yet another method of the class that will
        // switch the mode of window to the "update"
        // one here
        public void UpdateTest(Test test)
        {
            Mode = FormMode.Update;
            Test = test;
            InitializeControls();
            ShowTestInControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        // An Initializer components that was supposed
        // to do some job with Applicant part but not
        // used at the end of the work
        private void InitializeControls()
        {
        }

        // If the data is being updated instead of create
        // it will grab the last sessions's data so it will
        // be typed there already
        private void ShowTestInControls()
        {
            tbxName.Text = Test.ts_name_10023;
            tbxQ1.Text = Test.ts_q1_10023;
            tbxQ1Answer.Text = Test.ts_q1_answer_10023;
            tbxQ2.Text = Test.ts_q2_10023;
            tbxQ2Answer.Text = Test.ts_q2_answer_10023;
            tbxQ3.Text = Test.ts_q3_10023;
            tbxQ3Answer.Text = Test.ts_q3_answer_10023;
        }

        // At the end of creation or edit, just take the final
        // results and appoint it to the created Test class
        // to get to the next step ahead
        private void GrabUserInput()
        {
            Test.ts_name_10023 = tbxName.Text;
            Test.ts_q1_10023 = tbxQ1.Text;
            Test.ts_q1_answer_10023 = tbxQ1Answer.Text;
            Test.ts_q2_10023 = tbxQ2.Text;
            Test.ts_q2_answer_10023 = tbxQ2Answer.Text;
            Test.ts_q3_10023 = tbxQ3.Text;
            Test.ts_q3_answer_10023 = tbxQ3Answer.Text;

        }

        // The legendary cancel button here with its his dark 
        // magical behaivor. Just closes the window, nothin' else
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        // The slavey save button that cares about all final datas
        // Takes all appointed data and proceed with its backend
        // connection by sending and saving the infos
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                GrabUserInput();
                var manager = new TestManager();
                if (Mode == FormMode.CreateNew)
                    manager.Create(Test);
                else
                    manager.Update(Test);

                MyForms.GetForm<TestListForm>().LoadData();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
