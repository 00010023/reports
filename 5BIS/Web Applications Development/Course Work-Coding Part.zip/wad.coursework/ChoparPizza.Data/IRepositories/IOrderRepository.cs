﻿using ChoparPizza.Domain.Entities.Orders;

namespace ChoparPizza.Data.IRepositories
{
    public interface IOrderRepository : IGenericRepository<Order>
    {
    }
}
