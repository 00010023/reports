# Coursework of Web Application Development

> Notes: I couldn't finish the whole coursework 
> by only doing API as I spent most of my time 
> trying to figure out what's happening on docs

It's built using modular repository pattern.