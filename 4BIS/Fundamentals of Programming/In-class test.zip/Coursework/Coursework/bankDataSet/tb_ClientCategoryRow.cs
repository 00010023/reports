﻿namespace bankDataSet
{
    internal class tb_ClientCategoryRow
    {
    }
}