﻿using CW.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CW
{
    public partial class ApplicantEditForm : Form
    {
        // Initializing the component design
        public ApplicantEditForm()
        {
            InitializeComponent();
        }

        // Initializing the setter and getters of
        // Applicant class in CW.DAL
        public Applicant Applicant { get; set; }

        // The same thing is goin' on here also
        // in the FormMode setters and getters
        public FormMode Mode { get; set; }

        // The mechanic of class "create" function
        // and its his beauty described via usage
        // of MdiParen respectives
        public void CreateNewApplicant()
        {
            Mode = FormMode.CreateNew;
            Applicant = new Applicant();
            InitializeControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        // Yet another method of the class that will
        // switch the mode of window to the "update"
        // one here
        public void UpdateApplicant(Applicant applicant)
        {
            Mode = FormMode.Update;
            Applicant = applicant;
            InitializeControls();
            ShowApplicantInControls();
            MdiParent = MyForms.GetForm<ParentForm>();
            Show();
        }

        // That is supposed to work with cbx component
        // but as mentioned ap_tests_taken as string
        // I thought like no need to use cbx instead
        // ordinary textbox
        private void InitializeControls()
        {
        }

        // If the data is being updated instead of create
        // it will grab the last sessions's data so it will
        // be typed there already
        private void ShowApplicantInControls()
        {
            tbxName.Text = Applicant.ap_name_10023;
            nmrScore.Value = Applicant.ap_score_10023;
            tbxTests.Text = Applicant.ap_tests_taken_10023;
        }

        // At the end of creation or edit, just take the final
        // results and appoint it to the created Applicant class
        // to get to the next step ahead
        private void GrabUserInput()
        {
            Applicant.ap_name_10023 = tbxName.Text;
            Applicant.ap_score_10023 = (int)nmrScore.Value;
            Applicant.ap_tests_taken_10023 = (string)tbxTests.Text;
        }

        // The legendary cancel button here with its his dark 
        // magical behaivor. Just closes the window, nothin' else
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        // The slavey save button that cares about all final datas
        // Takes all appointed data and proceed with its backend
        // connection by sending and saving the infos
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                GrabUserInput();
                var manager = new ApplicantManager();
                if (Mode == FormMode.CreateNew)
                    manager.Create(Applicant);
                else
                    manager.Update(Applicant);

                MyForms.GetForm<ApplicantListForm>().LoadData();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
