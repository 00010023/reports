﻿
namespace CW
{
    partial class TestEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbxName = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbxQ1 = new System.Windows.Forms.TextBox();
            this.tbxQ1Answer = new System.Windows.Forms.TextBox();
            this.tbxQ2 = new System.Windows.Forms.TextBox();
            this.tbxQ2Answer = new System.Windows.Forms.TextBox();
            this.tbxQ3 = new System.Windows.Forms.TextBox();
            this.tbxQ3Answer = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // tbxName
            // 
            this.tbxName.Location = new System.Drawing.Point(114, 8);
            this.tbxName.Name = "tbxName";
            this.tbxName.Size = new System.Drawing.Size(251, 20);
            this.tbxName.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(290, 187);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Question 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Question 1 Answer";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Question 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Question 2 Answer";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Question 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 164);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Question 3 Answer";
            // 
            // tbxQ1
            // 
            this.tbxQ1.Location = new System.Drawing.Point(114, 35);
            this.tbxQ1.Name = "tbxQ1";
            this.tbxQ1.Size = new System.Drawing.Size(251, 20);
            this.tbxQ1.TabIndex = 9;
            // 
            // tbxQ1Answer
            // 
            this.tbxQ1Answer.Location = new System.Drawing.Point(114, 61);
            this.tbxQ1Answer.Name = "tbxQ1Answer";
            this.tbxQ1Answer.Size = new System.Drawing.Size(251, 20);
            this.tbxQ1Answer.TabIndex = 10;
            // 
            // tbxQ2
            // 
            this.tbxQ2.Location = new System.Drawing.Point(114, 87);
            this.tbxQ2.Name = "tbxQ2";
            this.tbxQ2.Size = new System.Drawing.Size(251, 20);
            this.tbxQ2.TabIndex = 11;
            // 
            // tbxQ2Answer
            // 
            this.tbxQ2Answer.Location = new System.Drawing.Point(114, 112);
            this.tbxQ2Answer.Name = "tbxQ2Answer";
            this.tbxQ2Answer.Size = new System.Drawing.Size(251, 20);
            this.tbxQ2Answer.TabIndex = 12;
            // 
            // tbxQ3
            // 
            this.tbxQ3.Location = new System.Drawing.Point(114, 138);
            this.tbxQ3.Name = "tbxQ3";
            this.tbxQ3.Size = new System.Drawing.Size(251, 20);
            this.tbxQ3.TabIndex = 13;
            // 
            // tbxQ3Answer
            // 
            this.tbxQ3Answer.Location = new System.Drawing.Point(114, 161);
            this.tbxQ3Answer.Name = "tbxQ3Answer";
            this.tbxQ3Answer.Size = new System.Drawing.Size(251, 20);
            this.tbxQ3Answer.TabIndex = 14;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(209, 187);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // TestEditForm
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(375, 223);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.tbxQ3Answer);
            this.Controls.Add(this.tbxQ3);
            this.Controls.Add(this.tbxQ2Answer);
            this.Controls.Add(this.tbxQ2);
            this.Controls.Add(this.tbxQ1Answer);
            this.Controls.Add(this.tbxQ1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.tbxName);
            this.Controls.Add(this.label1);
            this.Name = "TestEditForm";
            this.Text = "Edit a Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxName;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbxQ1;
        private System.Windows.Forms.TextBox tbxQ1Answer;
        private System.Windows.Forms.TextBox tbxQ2;
        private System.Windows.Forms.TextBox tbxQ2Answer;
        private System.Windows.Forms.TextBox tbxQ3;
        private System.Windows.Forms.TextBox tbxQ3Answer;
        private System.Windows.Forms.Button btnSave;
    }
}