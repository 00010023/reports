﻿using ChoparPizza.Domain.Entities.Pizzas;

namespace ChoparPizza.Data.IRepositories
{
    public interface IPizzaRepository : IGenericRepository<Pizza>
    {
    }
}
