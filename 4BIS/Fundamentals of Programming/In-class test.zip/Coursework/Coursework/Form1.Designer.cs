﻿
namespace Coursework
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label clientName_00010023Label1;
            System.Windows.Forms.Label clientAddress_00010023Label1;
            System.Windows.Forms.Label clientDOB_00010023Label1;
            System.Windows.Forms.Label clientBalance_00010023Label1;
            System.Windows.Forms.Label clientCategory_00010023Label1;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bankDataSet = new Coursework.BankDataSet();
            this.tb_ClientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_ClientTableAdapter = new Coursework.BankDataSetTableAdapters.tb_ClientTableAdapter();
            this.tableAdapterManager = new Coursework.BankDataSetTableAdapters.TableAdapterManager();
            this.tb_ClientBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tb_ClientBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.clientName_00010023TextBox1 = new System.Windows.Forms.TextBox();
            this.clientAddress_00010023TextBox1 = new System.Windows.Forms.TextBox();
            this.clientDOB_00010023DateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tbClientCategoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_ClientCategoryTableAdapter = new Coursework.BankDataSetTableAdapters.tb_ClientCategoryTableAdapter();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.tbxNewDOB = new System.Windows.Forms.DateTimePicker();
            this.tbxNewAddress = new System.Windows.Forms.TextBox();
            this.tbxNewCategory = new System.Windows.Forms.ComboBox();
            this.tbClientCategoryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tbxNewFullName = new System.Windows.Forms.TextBox();
            this.tbxNewBalance = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbxFilter = new System.Windows.Forms.TextBox();
            clientName_00010023Label1 = new System.Windows.Forms.Label();
            clientAddress_00010023Label1 = new System.Windows.Forms.Label();
            clientDOB_00010023Label1 = new System.Windows.Forms.Label();
            clientBalance_00010023Label1 = new System.Windows.Forms.Label();
            clientCategory_00010023Label1 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bankDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ClientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ClientBindingNavigator)).BeginInit();
            this.tb_ClientBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbClientCategoryBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbClientCategoryBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbxNewBalance)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // clientName_00010023Label1
            // 
            clientName_00010023Label1.AutoSize = true;
            clientName_00010023Label1.Location = new System.Drawing.Point(6, 21);
            clientName_00010023Label1.Name = "clientName_00010023Label1";
            clientName_00010023Label1.Size = new System.Drawing.Size(57, 13);
            clientName_00010023Label1.TabIndex = 17;
            clientName_00010023Label1.Text = "Full Name:";
            // 
            // clientAddress_00010023Label1
            // 
            clientAddress_00010023Label1.AutoSize = true;
            clientAddress_00010023Label1.Location = new System.Drawing.Point(6, 47);
            clientAddress_00010023Label1.Name = "clientAddress_00010023Label1";
            clientAddress_00010023Label1.Size = new System.Drawing.Size(48, 13);
            clientAddress_00010023Label1.TabIndex = 19;
            clientAddress_00010023Label1.Text = "Address:";
            // 
            // clientDOB_00010023Label1
            // 
            clientDOB_00010023Label1.AutoSize = true;
            clientDOB_00010023Label1.Location = new System.Drawing.Point(6, 74);
            clientDOB_00010023Label1.Name = "clientDOB_00010023Label1";
            clientDOB_00010023Label1.Size = new System.Drawing.Size(68, 13);
            clientDOB_00010023Label1.TabIndex = 21;
            clientDOB_00010023Label1.Text = "Date of birth:";
            // 
            // clientBalance_00010023Label1
            // 
            clientBalance_00010023Label1.AutoSize = true;
            clientBalance_00010023Label1.Location = new System.Drawing.Point(6, 99);
            clientBalance_00010023Label1.Name = "clientBalance_00010023Label1";
            clientBalance_00010023Label1.Size = new System.Drawing.Size(46, 13);
            clientBalance_00010023Label1.TabIndex = 23;
            clientBalance_00010023Label1.Text = "Balance";
            // 
            // clientCategory_00010023Label1
            // 
            clientCategory_00010023Label1.AutoSize = true;
            clientCategory_00010023Label1.Location = new System.Drawing.Point(6, 125);
            clientCategory_00010023Label1.Name = "clientCategory_00010023Label1";
            clientCategory_00010023Label1.Size = new System.Drawing.Size(49, 13);
            clientCategory_00010023Label1.TabIndex = 25;
            clientCategory_00010023Label1.Text = "Category";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(6, 125);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(49, 13);
            label1.TabIndex = 25;
            label1.Text = "Category";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(6, 99);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(46, 13);
            label2.TabIndex = 23;
            label2.Text = "Balance";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(6, 74);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(68, 13);
            label3.TabIndex = 21;
            label3.Text = "Date of birth:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(6, 47);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(48, 13);
            label4.TabIndex = 19;
            label4.Text = "Address:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(6, 21);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(57, 13);
            label5.TabIndex = 17;
            label5.Text = "Full Name:";
            // 
            // bankDataSet
            // 
            this.bankDataSet.DataSetName = "BankDataSet";
            this.bankDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_ClientBindingSource
            // 
            this.tb_ClientBindingSource.DataMember = "tb_Client";
            this.tb_ClientBindingSource.DataSource = this.bankDataSet;
            this.tb_ClientBindingSource.CurrentChanged += new System.EventHandler(this.tb_ClientBindingSource_CurrentChanged);
            // 
            // tb_ClientTableAdapter
            // 
            this.tb_ClientTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tb_ClientCategoryTableAdapter = null;
            this.tableAdapterManager.tb_ClientTableAdapter = this.tb_ClientTableAdapter;
            this.tableAdapterManager.UpdateOrder = Coursework.BankDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tb_ClientBindingNavigator
            // 
            this.tb_ClientBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tb_ClientBindingNavigator.BindingSource = this.tb_ClientBindingSource;
            this.tb_ClientBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tb_ClientBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tb_ClientBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tb_ClientBindingNavigatorSaveItem});
            this.tb_ClientBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tb_ClientBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tb_ClientBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tb_ClientBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tb_ClientBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tb_ClientBindingNavigator.Name = "tb_ClientBindingNavigator";
            this.tb_ClientBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tb_ClientBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.tb_ClientBindingNavigator.TabIndex = 0;
            this.tb_ClientBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tb_ClientBindingNavigatorSaveItem
            // 
            this.tb_ClientBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tb_ClientBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tb_ClientBindingNavigatorSaveItem.Image")));
            this.tb_ClientBindingNavigatorSaveItem.Name = "tb_ClientBindingNavigatorSaveItem";
            this.tb_ClientBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tb_ClientBindingNavigatorSaveItem.Text = "Save Data";
            this.tb_ClientBindingNavigatorSaveItem.Click += new System.EventHandler(this.tb_ClientBindingNavigatorSaveItem_Click);
            // 
            // listBox1
            // 
            this.listBox1.DataSource = this.tb_ClientBindingSource;
            this.listBox1.DisplayMember = "ClientName_00010023";
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 74);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(142, 186);
            this.listBox1.TabIndex = 1;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // clientName_00010023TextBox1
            // 
            this.clientName_00010023TextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_ClientBindingSource, "ClientName_00010023", true));
            this.clientName_00010023TextBox1.Location = new System.Drawing.Point(84, 18);
            this.clientName_00010023TextBox1.Name = "clientName_00010023TextBox1";
            this.clientName_00010023TextBox1.Size = new System.Drawing.Size(200, 20);
            this.clientName_00010023TextBox1.TabIndex = 18;
            this.clientName_00010023TextBox1.Validating += new System.ComponentModel.CancelEventHandler(this.clientName_00010023TextBox1_Validating);
            // 
            // clientAddress_00010023TextBox1
            // 
            this.clientAddress_00010023TextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_ClientBindingSource, "ClientAddress_00010023", true));
            this.clientAddress_00010023TextBox1.Location = new System.Drawing.Point(84, 44);
            this.clientAddress_00010023TextBox1.Name = "clientAddress_00010023TextBox1";
            this.clientAddress_00010023TextBox1.Size = new System.Drawing.Size(200, 20);
            this.clientAddress_00010023TextBox1.TabIndex = 20;
            this.clientAddress_00010023TextBox1.Validating += new System.ComponentModel.CancelEventHandler(this.clientAddress_00010023TextBox1_Validating);
            // 
            // clientDOB_00010023DateTimePicker1
            // 
            this.clientDOB_00010023DateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.clientDOB_00010023DateTimePicker1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tb_ClientBindingSource, "ClientDOB_00010023", true));
            this.clientDOB_00010023DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.clientDOB_00010023DateTimePicker1.Location = new System.Drawing.Point(84, 70);
            this.clientDOB_00010023DateTimePicker1.Name = "clientDOB_00010023DateTimePicker1";
            this.clientDOB_00010023DateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.clientDOB_00010023DateTimePicker1.TabIndex = 22;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tb_ClientBindingSource, "ClientBalance_00010023", true));
            this.numericUpDown1.Location = new System.Drawing.Point(84, 96);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(200, 20);
            this.numericUpDown1.TabIndex = 27;
            // 
            // comboBox1
            // 
            this.comboBox1.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tb_ClientBindingSource, "ClientCategory_00010023", true));
            this.comboBox1.DataSource = this.tbClientCategoryBindingSource;
            this.comboBox1.DisplayMember = "ClientCategoryName_00010023";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(84, 122);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 21);
            this.comboBox1.TabIndex = 28;
            this.comboBox1.ValueMember = "ID_00010023";
            // 
            // tbClientCategoryBindingSource
            // 
            this.tbClientCategoryBindingSource.DataMember = "tb_ClientCategory";
            this.tbClientCategoryBindingSource.DataSource = this.bankDataSet;
            // 
            // tb_ClientCategoryTableAdapter
            // 
            this.tb_ClientCategoryTableAdapter.ClearBeforeFill = true;
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(12, 266);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(31, 29);
            this.btnFirst.TabIndex = 29;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(49, 266);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(31, 29);
            this.btnPrevious.TabIndex = 30;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(86, 266);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(31, 29);
            this.btnNext.TabIndex = 31;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(123, 266);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(31, 29);
            this.btnLast.TabIndex = 32;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(9, 149);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(133, 23);
            this.btnDelete.TabIndex = 33;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(145, 149);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(139, 23);
            this.btnSave.TabIndex = 34;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(label5);
            this.groupBox1.Controls.Add(label1);
            this.groupBox1.Controls.Add(label2);
            this.groupBox1.Controls.Add(this.tbxNewDOB);
            this.groupBox1.Controls.Add(label3);
            this.groupBox1.Controls.Add(this.tbxNewAddress);
            this.groupBox1.Controls.Add(label4);
            this.groupBox1.Controls.Add(this.tbxNewCategory);
            this.groupBox1.Controls.Add(this.tbxNewFullName);
            this.groupBox1.Controls.Add(this.tbxNewBalance);
            this.groupBox1.Location = new System.Drawing.Point(496, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(292, 250);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Create";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(145, 149);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(139, 23);
            this.btnAdd.TabIndex = 35;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // tbxNewDOB
            // 
            this.tbxNewDOB.CustomFormat = "dd/MM/yyyy";
            this.tbxNewDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tbxNewDOB.Location = new System.Drawing.Point(84, 70);
            this.tbxNewDOB.Name = "tbxNewDOB";
            this.tbxNewDOB.Size = new System.Drawing.Size(200, 20);
            this.tbxNewDOB.TabIndex = 22;
            // 
            // tbxNewAddress
            // 
            this.tbxNewAddress.Location = new System.Drawing.Point(84, 44);
            this.tbxNewAddress.Name = "tbxNewAddress";
            this.tbxNewAddress.Size = new System.Drawing.Size(200, 20);
            this.tbxNewAddress.TabIndex = 20;
            // 
            // tbxNewCategory
            // 
            this.tbxNewCategory.DataSource = this.tbClientCategoryBindingSource1;
            this.tbxNewCategory.DisplayMember = "ClientCategoryName_00010023";
            this.tbxNewCategory.FormattingEnabled = true;
            this.tbxNewCategory.Location = new System.Drawing.Point(84, 122);
            this.tbxNewCategory.Name = "tbxNewCategory";
            this.tbxNewCategory.Size = new System.Drawing.Size(200, 21);
            this.tbxNewCategory.TabIndex = 28;
            this.tbxNewCategory.ValueMember = "ID_00010023";
            // 
            // tbClientCategoryBindingSource1
            // 
            this.tbClientCategoryBindingSource1.DataMember = "tb_ClientCategory";
            this.tbClientCategoryBindingSource1.DataSource = this.bankDataSet;
            // 
            // tbxNewFullName
            // 
            this.tbxNewFullName.Location = new System.Drawing.Point(84, 18);
            this.tbxNewFullName.Name = "tbxNewFullName";
            this.tbxNewFullName.Size = new System.Drawing.Size(200, 20);
            this.tbxNewFullName.TabIndex = 18;
            // 
            // tbxNewBalance
            // 
            this.tbxNewBalance.Location = new System.Drawing.Point(84, 96);
            this.tbxNewBalance.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.tbxNewBalance.Name = "tbxNewBalance";
            this.tbxNewBalance.Size = new System.Drawing.Size(200, 20);
            this.tbxNewBalance.TabIndex = 27;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(clientName_00010023Label1);
            this.groupBox2.Controls.Add(clientCategory_00010023Label1);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(clientBalance_00010023Label1);
            this.groupBox2.Controls.Add(this.btnDelete);
            this.groupBox2.Controls.Add(this.clientDOB_00010023DateTimePicker1);
            this.groupBox2.Controls.Add(clientDOB_00010023Label1);
            this.groupBox2.Controls.Add(this.clientAddress_00010023TextBox1);
            this.groupBox2.Controls.Add(clientAddress_00010023Label1);
            this.groupBox2.Controls.Add(this.clientName_00010023TextBox1);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.numericUpDown1);
            this.groupBox2.Location = new System.Drawing.Point(172, 45);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(292, 250);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Check and Modify";
            // 
            // tbxFilter
            // 
            this.tbxFilter.Location = new System.Drawing.Point(12, 45);
            this.tbxFilter.Name = "tbxFilter";
            this.tbxFilter.Size = new System.Drawing.Size(141, 20);
            this.tbxFilter.TabIndex = 37;
            this.tbxFilter.TextChanged += new System.EventHandler(this.tbxFilter_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 308);
            this.Controls.Add(this.tbxFilter);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.tb_ClientBindingNavigator);
            this.Name = "Form1";
            this.Text = "Coursework 00010023";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bankDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ClientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ClientBindingNavigator)).EndInit();
            this.tb_ClientBindingNavigator.ResumeLayout(false);
            this.tb_ClientBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbClientCategoryBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbClientCategoryBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbxNewBalance)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BankDataSet bankDataSet;
        private System.Windows.Forms.BindingSource tb_ClientBindingSource;
        private BankDataSetTableAdapters.tb_ClientTableAdapter tb_ClientTableAdapter;
        private BankDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tb_ClientBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tb_ClientBindingNavigatorSaveItem;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox clientName_00010023TextBox1;
        private System.Windows.Forms.TextBox clientAddress_00010023TextBox1;
        private System.Windows.Forms.DateTimePicker clientDOB_00010023DateTimePicker1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.BindingSource tbClientCategoryBindingSource;
        private BankDataSetTableAdapters.tb_ClientCategoryTableAdapter tb_ClientCategoryTableAdapter;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker tbxNewDOB;
        private System.Windows.Forms.TextBox tbxNewAddress;
        private System.Windows.Forms.ComboBox tbxNewCategory;
        private System.Windows.Forms.TextBox tbxNewFullName;
        private System.Windows.Forms.NumericUpDown tbxNewBalance;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.BindingSource tbClientCategoryBindingSource1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox tbxFilter;
    }
}

