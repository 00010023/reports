﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW.DAL
{
    public enum ByAttribute
    {
        ap_name_10023,

        ap_score_10023,

        ap_tests_taken_10023
    }
}
