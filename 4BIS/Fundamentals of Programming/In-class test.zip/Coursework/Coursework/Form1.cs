﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coursework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Validate())
            {
                this.tb_ClientBindingSource.EndEdit();
                if (bankDataSet.HasChanges())
                {
                    if (MessageBox.Show("Do you want to save changes?", "Save", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        SaveData();
                    }
                }
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void SaveData()
        {
            if (this.Validate())
            {
                try
                {
                    this.tb_ClientBindingSource.EndEdit();
                    this.tableAdapterManager.UpdateAll(this.bankDataSet);
                    MessageBox.Show("Data has been successfully saved!");
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
                
            }
        }

        private void tb_ClientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            SaveData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                this.tb_ClientCategoryTableAdapter.Fill(this.bankDataSet.tb_ClientCategory);
                this.tb_ClientTableAdapter.Fill(this.bankDataSet.tb_Client);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
            

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tb_ClientTableAdapter.FillBy(this.bankDataSet.tb_Client);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void clientBalance_00010023TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            tb_ClientBindingSource.MoveFirst();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            tb_ClientBindingSource.MovePrevious();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tb_ClientBindingSource.MoveNext();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tb_ClientBindingSource.MoveLast();
        }

        private void DynamicButtons()
        {
            if (tb_ClientBindingSource.Position == 0)
            {
                btnFirst.Enabled = false;
                btnPrevious.Enabled = false;
            }
            else
            {
                btnFirst.Enabled = true;
                btnPrevious.Enabled = true;
            }

            if (tb_ClientBindingSource.Position == tb_ClientBindingSource.Count - 1)
            {
                btnLast.Enabled = false;
                btnNext.Enabled = false;
            }
            else
            {
                btnLast.Enabled = true;
                btnNext.Enabled = true;
            }
        }

        private void tb_ClientBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DynamicButtons();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (tb_ClientBindingSource.Count is 0)
            {
                MessageBox.Show("No more record to delete!");
            }
            else
            {
                var choice = MessageBox.Show("Do you confirm that you want to delete this data?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (choice is DialogResult.Yes)
                {
                    tb_ClientBindingSource.RemoveCurrent();
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveData();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var selectedCategory = ((DataRowView)tbxNewCategory.SelectedItem).Row;

            bankDataSet.tb_Client.Addtb_ClientRow(tbxNewFullName.Text, tbxNewAddress.Text, tbxNewDOB.Value, Convert.ToInt32(tbxNewBalance.Value), (BankDataSet.tb_ClientCategoryRow) selectedCategory);
        }

        private void tbxFilter_TextChanged(object sender, EventArgs e)
        {
            tb_ClientBindingSource.Filter = $"ClientName_00010023 LIKE ('{tbxFilter.Text}%')";        
        }

        private void clientName_00010023TextBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(clientName_00010023TextBox1.Text))
            {
                MessageBox.Show("Name variable can not be empty!");
                e.Cancel = true;
            }
        }

        private void clientAddress_00010023TextBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(clientAddress_00010023TextBox1.Text))
            {
                MessageBox.Show("Address variable can not be empty!");
                e.Cancel = true;
            }
        }
    }
}
