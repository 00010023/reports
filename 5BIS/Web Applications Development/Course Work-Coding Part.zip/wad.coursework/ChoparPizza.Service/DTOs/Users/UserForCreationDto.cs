﻿namespace ChoparPizza.Service.DTOs.Users
{
    public class UserForCreationDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ShoppingCard { get; set; }
    }
}
