﻿using CW.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CW
{
    public partial class TestListForm : Form
    {
        // Initializes the design part of the program
        public TestListForm()
        {
            InitializeComponent();
        }

        // Initializes the datas by getting them from
        // backend
        private void TestListForm_Load(object sender, EventArgs e)
        {
            MdiParent = MyForms.GetForm<ParentForm>();
            LoadData();
        }

        // The refresh button that does the same as the
        // formload function
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        // The function that stands for refreshability of
        // the datas coming up from the backend
        public void LoadData()
        {
            dgv.DataMember = "";
            dgv.DataSource = null;
            dgv.DataSource = new TestList().GetAllTests();
        }

        // The delete button that is responsibe for deleting
        // datas from the database side by connecting with its
        // CW.DAL
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0)
                MessageBox.Show("Please select a course");
            else
            {
                var t = (Test)dgv.SelectedRows[0].DataBoundItem;
                new TestManager().Delete(t.ts_id_10023);
                LoadData();
            }
        }

        // The create button that does create a Test by telling
        // it to its backend side namely CW.DAL
        private void btnAdd_Click(object sender, EventArgs e)
        {
            new TestEditForm().CreateNewTest();
        }

        // The update button that does help user to manage or edit
        // existing data that is located at the database
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0)
                MessageBox.Show("Please select a course");
            else
            {
                var t = (Test)dgv.SelectedRows[0].DataBoundItem;
                new TestEditForm().UpdateTest(t);
            }

        }
    }
}
